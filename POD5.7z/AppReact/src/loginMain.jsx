var React = require('react');
var ReactDOM = require('react-dom');
var LoginContainer = require('./components/loginContainer.jsx');

ReactDOM.render(<LoginContainer />, document.getElementById('ingredients'));
