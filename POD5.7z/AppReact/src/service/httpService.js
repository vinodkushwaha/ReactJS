var Fetch = require('whatwg-fetch');
var baseUrl="http://10.217.101.112:8081/api";

var service ={
    
    post:function(url,data){
        var postObject = {  
                method: 'POST',
                body: JSON.stringify(data),
                headers: {
                    'Content-Type': 'text/plain',
                    'Access-Control-Allow-Headers': 'http://10.217.101.112:8081/api',
                    'Access-Control-Allow-Methods': '*'     
                }
                
            };
        
        return fetch(baseUrl+url,postObject).then(function(response){
                return response.json();
            });
    },
    get:function(url){
        return fetch(baseUrl+url)
        .then(function(response){
            return response.json();
        });
    }  
}



module.exports=service;