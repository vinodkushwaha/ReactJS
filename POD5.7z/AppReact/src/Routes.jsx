var React = require('react');
var ReactRouter = require('react-router');
var Router = ReactRouter.Router;
var Route = ReactRouter.Route;
var BrowserHistory = require('react-router');
var HashHistory  = require('react-router');


var SignUpContainer = require('./components/signUpContainer.jsx');
var LoginContainer = require('./components/loginContainer.jsx');
var HomePageContainer = require('./components/homePageComponent.jsx');

var Routes = (
    <Router history={BrowserHistory |HashHistory}>
            <Route path="/" component={LoginContainer}></Route>
            <Route path="/signUp" component={SignUpContainer}/>
            <Route path="/homePage" component={HomePageContainer}/>
        
    </Router>
);

module.exports=Routes;