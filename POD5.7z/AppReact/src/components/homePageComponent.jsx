var React = require('react');


var HomePageContainer = React.createClass({
    
     render: function() {     
        return (
             <div className="row">
                <div className="col-lg-12 col-md-12 col-xs-12 col-sm-12 ">
                    <h1>Welcome To Home Page</h1>
                </div>
            </div>
        );
    }
});

module.exports = HomePageContainer;
