var React = require('react');

var InputPasswordFieldComponent = React.createClass({
    getInitialState:function(){
        return {value:""}
    },
    onChange:function(e){
        this.setState({value:e.target.value});
    },
    render: function() {
        return (
            <div className="form-group">
                <input type="password" className="form-control" 
                    placeholder={this.props.placeholderText} 
                    value={this.state.value}
                    onChange={this.onChange}
                    pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}"
                    required
                />
            </div>           
        );
    }
});

module.exports = InputPasswordFieldComponent;
