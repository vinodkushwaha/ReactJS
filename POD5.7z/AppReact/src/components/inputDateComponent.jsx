var React = require('react');
var InputDateFieldComponent = React.createClass({
    getInitialState:function(){
        return {value:""}
    },
    onChange:function(e){
        this.setState({value:e.target.value});
    },
    render: function() {
        return (
            <div className="form-group">
                <input type="date" className="form-control date" 
                    placeholder={this.props.placeholderText}
                    value={this.state.value}
                    onChange={this.onChange} 
                    pattern="(?:19|20)[0-9]{2}-(?:(?:0[1-9]|1[0-2])-(?:0[1-9]|1[0-9]|2[0-9])|(?:(?!02)(?:0[1-9]|1[0-2])-(?:30))|(?:(?:0[13578]|1[02])-31))"
                    required
                    />
            </div>
        );
    }
});

module.exports = InputDateFieldComponent;
///<span className="glyphicon glyphicon-calendar"></span>