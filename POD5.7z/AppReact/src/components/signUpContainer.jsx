var React = require('react');

var InputTextFieldComponent = require('./inputTextFieldComponent.jsx');
var InputPasswordFieldComponent = require('./inputPasswordComponent.jsx');
var InputCheckboxComponent = require('./inputCheckboxComponent.jsx');
var InputDropdownComponent = require('./inputDropdownComponent.jsx');
var InputRadioComponent = require('./inputRadioComponent.jsx');
var InputDateComponent = require('./inputDateComponent.jsx');
var InputEmailFieldComponent = require('./inputEmailComponent.jsx');
var HTTP = require('../service/httpService');

var SignUpContainer = React.createClass({

    saveSignUp : function(e){
        var setGender="";
        if(this.refs.gender2.state.value)
            setGender="F";
        if(this.refs.gender1.state.value)
            setGender="M";
        
        HTTP.get("/registrUser?username="+this.refs.userName.state.value+
                    "&password="+this.refs.password.state.value+
                    "&gender="+setGender+
                    "&emailId="+this.refs.eMail.state.value+
                    "&dob="+this.refs.birthDate.state.value+
                    "&accountType="+this.refs.accountType.state.value).
                        then(function(data){
                            this.props.history.push('/homePage');   
                        }.bind(this));
        
    },
    cancelSignUp : function(e){
        this.props.history.push('/'); 
    },
    render: function() {
       
        return (
        <div className="row">
          <div className="col-lg-6 col-md-6 col-xs-12 col-sm-12 nopaddingstyle borderStyleall">
            <form className="form-horizontal">
                <div className="col-lg-12 col-md-12 col-xs-12 col-sm-12 formfielsStyle">
                      <div className="row">
                        <div className="col-lg-6 col-md-6 col-xs-12 col-sm-12">
                            <label>User Name</label>
                        </div>
                        <div className="col-lg-6 col-md-6 col-xs-12 col-sm-12 width45">
                            <InputTextFieldComponent ref="userName" placeholderText="Enter First Name"/>
                        </div>
                    </div>
                </div>
                <div className="col-lg-12 col-md-12 col-xs-12 col-sm-12 formfielsStyle">
                      <div className="row">
                        <div className="col-lg-6 col-md-6 col-xs-12 col-sm-12">
                            <label>Email</label>
                        </div>
                        <div className="col-lg-6 col-md-6 col-xs-12 col-sm-12 width45">
                            <InputEmailFieldComponent ref="eMail" placeholderText="Enter Email"/>
                        </div>
                    </div>
                </div>
                <div className="col-lg-12 col-md-12 col-xs-12 col-sm-12 formfielsStyle">
                      <div className="row">
                        <div className="col-lg-6 col-md-6 col-xs-12 col-sm-12">
                            <label>Set Password</label>
                        </div>
                        <div className="col-lg-6 col-md-6 col-xs-12 col-sm-12 width45">
                            <InputPasswordFieldComponent ref="password" placeholderText="Password"/>
                            <span>Password must contain at least 6 characters, inculding Upper/lowercase and numbers</span> 
                        </div>
                    </div>
                </div>
                <div className="col-lg-12 col-md-12 col-xs-12 col-sm-12 formfielsStyle">
                      <div className="row">
                        <div className="col-lg-6 col-md-6 col-xs-12 col-sm-12">
                            <label>Birth Date</label>
                        </div>
                        <div className="col-lg-6 col-md-6 col-xs-12 col-sm-12 width45">
                            <InputDateComponent ref="birthDate" placeholderText="Enter Birthdate"/>
                        </div>
                    </div>
                </div>
                <div className="col-lg-12 col-md-12 col-xs-12 col-sm-12 formfielsStyle">
                      <div className="row">
                            <div className="col-lg-4 col-md-3 col-xs-12 col-sm-12">
                                <label>Gender</label>
                            </div>
                          
                            <div className="col-lg-8 col-md-5 col-xs-12 col-sm-12 formGenderPadding">
                                <div className="row">
                                    <div className="col-lg-6 col-md-6 col-xs-12 col-sm-12">
                                      <InputRadioComponent ref="gender1" radioboxLabel="Male" name="gender" />
                                  </div>
                                  <div className="col-lg-6 col-md-6 col-xs-12 col-sm-12">
                                      <InputRadioComponent ref="gender2" radioboxLabel="Female" name="gender"/>                                    
                                  </div>
                              </div>
                          </div>
                    </div>
                </div>
                <div className="col-lg-12 col-md-12 col-xs-12 col-sm-12 formfielsStyle">
                      <div className="row">
                        <div className="col-lg-6 col-md-6 col-xs-12 col-sm-12">
                            <label>Account Type</label>
                        </div>
                        <div className="col-lg-6 col-md-6 col-xs-12 col-sm-12 width45">
                            <InputDropdownComponent ref="accountType" />
                        </div>
                    </div>
                </div>
                <div className="col-lg-12 col-md-12 col-xs-12 col-sm-12 formfielsStyle">
                      <div className="row">
                        <div className="col-lg-6 col-md-6 col-xs-12 col-sm-12">                   
                        </div>
                        <div className="col-lg-6 col-md-6 col-xs-12 col-sm-12">
                            <button className="btn btn-primary" onClick={this.saveSignUp}>Save</button>
                            <button className="btn btn-primary signUpbuttonmargtin" onClick={this.cancelSignUp}>Cancel</button>
                        </div>
                    </div>
                </div>            
            </form>
            </div>
        </div>
        );
    }
});

module.exports = SignUpContainer;
