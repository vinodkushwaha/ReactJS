var React = require('react');
var router = require('react-router');

var InputTextFieldComponent = require('./inputTextFieldComponent.jsx');
var InputPasswordFieldComponent = require('./inputPasswordComponent.jsx');

var HTTP = require('../service/httpService');


var LoginContainer = React.createClass({
    doSignUp : function(e){
        this.props.history.push('/signUp');       
    },
    doLogin : function(e){
        
        if(this.refs.userName.state.value!=""&&this.refs.password.state.value!=""){
            HTTP.get("/userLogin?username="+this.refs.userName.state.value+"&password="+this.refs.password.state.value).then(function(data){
            if(data.flag=="true"){
                this.props.history.push('/homePage');
            }

            else {
                alert("You are not Authorized to Login!!!!")   
                this.props.history.push('/');
                
            }
                
        }.bind(this));

        }
        
               
    },
     render: function() {     
        return (
             <div className="row">
                <div className="col-lg-6 col-md-6 col-xs-12 col-sm-12 nopaddingstyle borderStyleall">
                    <form className="form-horizontal">
                        <div className="col-lg-12 col-md-12 col-xs-12 col-sm-12 formfielsStyle">
                            <div className="row">
                                <div className="col-lg-6 col-md-6 col-xs-12 col-sm-12">
                                    <label>User Name</label>
                                </div>
                                <div className="col-lg-6 col-md-6 col-xs-12 col-sm-12 width45">
                                    <InputTextFieldComponent ref="userName" placeholderText="Enter  UserName"/>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-12 col-md-12 col-xs-12 col-sm-12 formfielsStyle">
                            <div className="row">
                                <div className="col-lg-6 col-md-6 col-xs-12 col-sm-12">
                                    <label>Password</label>
                                </div>
                                <div className="col-lg-6 col-md-6 col-xs-12 col-sm-12 width45">
                                    <InputPasswordFieldComponent ref="password" placeholderText="Password"/>
                                    <span>Password must contain at least 6 characters, inculding Upper/lowercase and numbers</span> 
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-12 col-md-12 col-xs-12 col-sm-12 formfielsStyle">
                            <div className="row">
                                <div className="col-lg-6 col-md-6 col-xs-12 col-sm-12">                   
                                </div>
                                <div className="col-lg-6 col-md-6 col-xs-12 col-sm-12">
                                    <button className="btn btn-primary" onClick={this.doLogin}>Login</button>
                                    <button className="btn btn-primary signUpbuttonmargtin" onClick={this.doSignUp}>SignUp</button>
                                </div>
                            </div>
                        </div>  
                    </form>
                </div>
            </div>
        );
    }
});

module.exports = LoginContainer;
