var React = require('react');
var InputTextFieldComponent = React.createClass({
    getInitialState:function(){
        return {value:""}
    },
    onChange:function(e){
        this.setState({value:e.target.value});
    },
    render: function() {
        return (
            <div className="form-group">
                <input type="text" className="form-control" 
                    placeholder={this.props.placeholderText} 
                    value={this.state.value}
                    onChange={this.onChange}
                    required
                    
                />
            </div>
        );
    }
});

module.exports = InputTextFieldComponent;
