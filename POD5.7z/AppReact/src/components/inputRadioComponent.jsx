var React = require('react');
var InputRadioComponent = React.createClass({
    getInitialState:function(){
        return {value:""}
    },
    onChange:function(e){
        this.setState({value:e.target.checked});
    },
    render: function() {
        return (
            <div className="form-group labelStylewhite">
                    <input type="radio" name={this.props.name}
                        value={this.state.value }
                        onChange={this.onChange}
                        required
                    >{this.props.radioboxLabel}</input>
            </div>
        );
    }
});

module.exports = InputRadioComponent;
