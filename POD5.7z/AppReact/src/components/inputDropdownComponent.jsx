var React = require('react');
var ListItem = require('./ListItem.jsx');

var listOptions =[
                    {"id":1,"accountType":"Savings Account"},
                    {"id":2,"accountType":"Demat Account"},
                    {"id":3,"accountType":"Reccuring Account"}
    ];
var InputDropdownComponent = React.createClass({
     getInitialState:function(){
        return {value:"Savings Account"}
    },
    onChange:function(e){
        this.setState({value:e.target.textContent});
    },
    render: function() {
        var listItems = listOptions.map(function(item) {
            return <ListItem key={item.id} ingredient={item.accountType} refs="accountTypeList"/>;
        });
        return (
            <div className="form-group">
                <div className="dropdown">
                        <button className="btn formButtonStyle dropdown-toggle" type="button" data-toggle="dropdown">
                                <span className="dropdownlabelstyle">{this.state.value}</span><span className="caret"></span></button>
                            <ul className="dropdown-menu" onClick={this.onChange}>
                                {listItems}
                            </ul>
                    </div>
            </div>
        );
    }
});

module.exports = InputDropdownComponent;
