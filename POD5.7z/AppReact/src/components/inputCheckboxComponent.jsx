var React = require('react');
var InputCheckboxComponent = React.createClass({
    render: function() {
        return (
            <div className="form-group">
                <input type="checkbox" required>{this.props.checkboxLabel}</input>
            </div>
        );
    }
});

module.exports = InputCheckboxComponent;
