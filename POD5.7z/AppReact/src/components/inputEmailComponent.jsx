var React = require('react');
var Validator = require('email-validator')

var InputEmailFieldComponent = React.createClass({
    getInitialState:function(){
        return {value:"",valid:true}
    },
    onChange:function(e){
        if(!Validator.validate(e.target.value)){
            this.setState({value:e.target.value,valid:false});
        } else{
            this.setState({value:e.target.value,valid:true});
        }
        
    },
    render: function() {
        var formClass=this.state.valid?"form-group":"form-group has-error";
        return (
            <div className={formClass}>
                <input type="email" className="form-control" 
                    placeholder={this.props.placeholderText} 
                    value={this.state.value}
                    onChange={this.onChange}
                    pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,63}$"
                    required
                />
            </div>
        );
    }
});

module.exports = InputEmailFieldComponent;
