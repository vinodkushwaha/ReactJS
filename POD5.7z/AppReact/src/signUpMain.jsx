var React = require('react');
var ReactDOM = require('react-dom');
var SignUpContainer = require('./components/signUpContainer.jsx');

ReactDOM.render(<SignUpContainer />, document.getElementById('ingredients'));
